import './App.css'
import Avalaibles from './components/Avalaibles';
import Lista from './components/Lista';
import beers from './components/Beers';
import BeersCount from './components/BeersCount';
import BeerStyles from './components/BeerStyles';

function App() {
  

  return (
    <>
      <div>   
      <Lista beers={beers}/>
      <Avalaibles beers={beers}/>
      <BeersCount beers={beers}/>
      <BeerStyles beers={beers}/>
      </div>
      
    </>
  )
}

export default App
